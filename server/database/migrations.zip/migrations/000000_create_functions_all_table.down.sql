BEGIN;

DROP FUNCTION IF EXISTS update_modified_column();

COMMIT;